package edu.niu.areacalculationexam;
/********************************************************************
 CSCI 522 - Midterm Exam - Semester (Spring) Year - 2019

 Programmer(s): Manoj Veluru
 Section: 1
 TA: Harshith Desamsetti
 Date Due: 03/25/2019

 Purpose: Android application that calculates area of different shapes

 *********************************************************************/
import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.DecimalFormat;

public class EllipseArea extends Activity {
    //instance variables
    private EditText majorAxisET, minorAxisET;
    private double lenOfMajorAxis, lenOfMinorAxis;
    private Button calculateButton;
    private static final double pi = 3.14159;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ellipse_area);
        //connect the instance variables with the objects on the screen
        majorAxisET = findViewById(R.id.majorEdit);
        minorAxisET = findViewById(R.id.minorEdit);
        calculateButton = findViewById(R.id.calcArea);
        //handle the calculate button click
        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //check for empty fields
                if(majorAxisET.getText().toString().matches("")|| minorAxisET.getText().toString().matches(""))
                {
                    Toast.makeText(v.getContext(),"Enter required data",Toast.LENGTH_SHORT).show();
                    return;
                }
                //get the fields that user entered
                lenOfMajorAxis = Double.parseDouble(majorAxisET.getText().toString());
                lenOfMinorAxis = Double.parseDouble(minorAxisET.getText().toString());
                //calculate area
                double area = pi * lenOfMajorAxis * lenOfMinorAxis;
                DecimalFormat df = new DecimalFormat("#0.0000");

                Intent intent;
                intent = getIntent();
                String calculatedArea = "Area of Ellipse is:  " +df.format(area);
                intent.putExtra("area",calculatedArea);
                ((Activity)v.getContext()).setResult(RESULT_OK,intent);
                finish();
            }
        });
    }//end onCreate
}//end EllipseArea
