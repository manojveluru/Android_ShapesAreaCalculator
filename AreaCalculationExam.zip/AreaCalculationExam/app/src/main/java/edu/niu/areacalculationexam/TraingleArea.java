package edu.niu.areacalculationexam;
/********************************************************************
 CSCI 522 - Midterm Exam - Semester (Spring) Year - 2019

 Programmer(s): Manoj Veluru
 Section: 1
 TA: Harshith Desamsetti
 Date Due: 03/25/2019

 Purpose: Android application that calculates area of different shapes

 *********************************************************************/
import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.text.DecimalFormat;

public class TraingleArea extends Activity {
    //instance variables
    private EditText baseET, heightET;
    private double base, height;
    private Button calculateButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_traingle_area);
        //connect the instance variables with the objects on the screen
        baseET = findViewById(R.id.baseEdit);
        heightET = findViewById(R.id.heightEdit);
        calculateButton = findViewById(R.id.areaCalc);
        //handle the calculate button click
        calculateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //check for empty fields
                if(baseET.getText().toString().matches("")|| heightET.getText().toString().matches(""))
                {
                    Toast.makeText(v.getContext(),"Enter required data",Toast.LENGTH_SHORT).show();
                    return;
                }
                //get the fields that user entered
                base = Double.parseDouble(baseET.getText().toString());
                height = Double.parseDouble(heightET.getText().toString());
                //calculate area
                double area = 0.5*base*height;
                DecimalFormat df = new DecimalFormat("#0.0000");

                Intent intent;
                intent = getIntent();
                String calculatedArea = "Area of Triangle is:  " +df.format(area);
                intent.putExtra("area",calculatedArea);
                ((Activity)v.getContext()).setResult(RESULT_OK,intent);
                finish();
            }
        });
    }//end onCreate



}//end TraingleArea
