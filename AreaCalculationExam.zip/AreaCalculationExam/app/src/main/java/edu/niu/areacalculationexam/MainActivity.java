package edu.niu.areacalculationexam;
/********************************************************************
 CSCI 522 - Midterm Exam - Semester (Spring) Year - 2019

 Programmer(s): Manoj Veluru
 Section: 1
 TA: Harshith Desamsetti
 Date Due: 03/25/2019

 Purpose: Android application that calculates area of different shapes

 *********************************************************************/
import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private RadioGroup shapesRG;
    private TextView calculateTV;
    String shape = "";
    static final int REQUEST_CODE = 13;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //connect variables to the objects on the screen
        shapesRG = findViewById(R.id.shapeRadioGroup);
        calculateTV = findViewById(R.id.areaTextView);

        shapesRG.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId)
            {
                switch (checkedId)
                {
                    case R.id.triangleRadioButton: shape = "traingle";break;
                    case R.id.circleRadioButton: shape = "circle";break;
                    case R.id.ellipseRadioButton: shape = "ellipse";break;

                }

            }
        });


    }//end onCreate

    public void getArea(View view)
    {
        Intent intent;
        if(shape.equals("traingle"))
        {
            intent = new Intent(MainActivity.this,TraingleArea.class);
            startActivityForResult(intent,REQUEST_CODE);
        }
        else if(shape.equals("circle"))
        {
            intent = new Intent(MainActivity.this,CircleArea.class);
            startActivityForResult(intent,REQUEST_CODE);
        }
        else if(shape.equals("ellipse"))
        {
            intent = new Intent(MainActivity.this,EllipseArea.class);
            startActivityForResult(intent,REQUEST_CODE);
        }
        else
            {
                Toast.makeText(view.getContext(),"Make a selection first",Toast.LENGTH_SHORT).show();
            }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        //super.onActivityResult(requestCode, resultCode, data);
        String calculatedArea;
        if(requestCode == REQUEST_CODE && resultCode==RESULT_OK)
        {
            calculatedArea = data.getStringExtra("area");
            calculateTV.setText(calculatedArea);
        }
    }
}//end MainActivity
